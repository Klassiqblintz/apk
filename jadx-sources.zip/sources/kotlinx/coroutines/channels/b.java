package kotlinx.coroutines.channels;

import kotlin.TuplesKt;
import kotlin.jvm.functions.Function2;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class b implements Function2 {
    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        return TuplesKt.to(obj, obj2);
    }
}
