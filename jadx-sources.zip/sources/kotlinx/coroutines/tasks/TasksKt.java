package kotlinx.coroutines.tasks;

import a.AbstractC1629oU;
import a.C0723ab;
import a.C1050fa;
import a.C1694pU;
import a.C2051v0;
import a.C2271yN;
import a.H20;
import a.MC;
import a.QI;
import java.util.concurrent.CancellationException;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.sequences.Sequence;
import kotlinx.coroutines.CancellableContinuation;
import kotlinx.coroutines.CancellableContinuationImpl;
import kotlinx.coroutines.ChildHandle;
import kotlinx.coroutines.ChildJob;
import kotlinx.coroutines.CompletableDeferred;
import kotlinx.coroutines.CompletableDeferredKt;
import kotlinx.coroutines.Deferred;
import kotlinx.coroutines.DisposableHandle;
import kotlinx.coroutines.ExperimentalCoroutinesApi;
import kotlinx.coroutines.InternalCoroutinesApi;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.selects.SelectClause0;
import kotlinx.coroutines.selects.SelectClause1;

/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0016\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\b\u001a#\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u0001¢\u0006\u0004\b\u0003\u0010\u0004\u001a#\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u0002¢\u0006\u0004\b\u0005\u0010\u0006\u001a-\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00022\u0006\u0010\b\u001a\u00020\u0007H\u0007¢\u0006\u0004\b\u0005\u0010\t\u001a/\u0010\n\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00022\b\u0010\b\u001a\u0004\u0018\u00010\u0007H\u0002¢\u0006\u0004\b\n\u0010\t\u001a \u0010\u000b\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0086@¢\u0006\u0004\b\u000b\u0010\f\u001a(\u0010\u000b\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00022\u0006\u0010\b\u001a\u00020\u0007H\u0087@¢\u0006\u0004\b\u000b\u0010\r\u001a*\u0010\u000e\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00022\b\u0010\b\u001a\u0004\u0018\u00010\u0007H\u0082@¢\u0006\u0004\b\u000e\u0010\r¨\u0006\u000f"}, d2 = {"T", "Lkotlinx/coroutines/Deferred;", "La/oU;", "asTask", "(Lkotlinx/coroutines/Deferred;)La/oU;", "asDeferred", "(La/oU;)Lkotlinx/coroutines/Deferred;", "La/ab;", "cancellationTokenSource", "(La/oU;La/ab;)Lkotlinx/coroutines/Deferred;", "asDeferredImpl", "await", "(La/oU;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "(La/oU;La/ab;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "awaitImpl", "kotlinx-coroutines-play-services"}, k = 2, mv = {2, 0, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nTasks.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Tasks.kt\nkotlinx/coroutines/tasks/TasksKt\n+ 2 CancellableContinuation.kt\nkotlinx/coroutines/CancellableContinuationKt\n*L\n1#1,164:1\n351#2,11:165\n*S KotlinDebug\n*F\n+ 1 Tasks.kt\nkotlinx/coroutines/tasks/TasksKt\n*L\n136#1:165,11\n*E\n"})
public final class TasksKt {
    public static final <T> Deferred<T> asDeferred(AbstractC1629oU abstractC1629oU) {
        return asDeferredImpl(abstractC1629oU, null);
    }

    @ExperimentalCoroutinesApi
    public static final <T> Deferred<T> asDeferred(AbstractC1629oU abstractC1629oU, C0723ab c0723ab) {
        return asDeferredImpl(abstractC1629oU, c0723ab);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private static final <T> Deferred<T> asDeferredImpl(AbstractC1629oU abstractC1629oU, C0723ab c0723ab) {
        final CompletableDeferred completableDeferredCompletableDeferred$default = CompletableDeferredKt.CompletableDeferred$default(null, 1, null);
        if (abstractC1629oU.e()) {
            Exception excC = abstractC1629oU.c();
            if (excC != null) {
                completableDeferredCompletableDeferred$default.completeExceptionally(excC);
            } else if (((H20) abstractC1629oU).d) {
                Job.DefaultImpls.cancel$default((Job) completableDeferredCompletableDeferred$default, (CancellationException) null, 1, (Object) null);
            } else {
                completableDeferredCompletableDeferred$default.complete(abstractC1629oU.d());
            }
        } else {
            abstractC1629oU.a(DirectExecutor.INSTANCE, new C2051v0(completableDeferredCompletableDeferred$default, 6));
        }
        if (c0723ab != null) {
            completableDeferredCompletableDeferred$default.invokeOnCompletion(new C1050fa(c0723ab, 6));
        }
        return new Deferred<T>() { // from class: kotlinx.coroutines.tasks.TasksKt.asDeferredImpl.3
            @Override // kotlinx.coroutines.Job
            @InternalCoroutinesApi
            public ChildHandle attachChild(ChildJob child) {
                return completableDeferredCompletableDeferred$default.attachChild(child);
            }

            @Override // kotlinx.coroutines.Deferred
            public Object await(Continuation<? super T> continuation) {
                return completableDeferredCompletableDeferred$default.await(continuation);
            }

            @Override // kotlinx.coroutines.Job
            @Deprecated(level = DeprecationLevel.HIDDEN, message = "Since 1.2.0, binary compatibility with versions <= 1.1.x")
            public /* synthetic */ void cancel() {
                completableDeferredCompletableDeferred$default.cancel();
            }

            @Override // kotlinx.coroutines.Job
            public void cancel(CancellationException cause) {
                completableDeferredCompletableDeferred$default.cancel(cause);
            }

            @Override // kotlinx.coroutines.Job
            @Deprecated(level = DeprecationLevel.HIDDEN, message = "Since 1.2.0, binary compatibility with versions <= 1.1.x")
            public /* synthetic */ boolean cancel(Throwable cause) {
                return completableDeferredCompletableDeferred$default.cancel(cause);
            }

            @Override // kotlin.coroutines.CoroutineContext.Element, kotlin.coroutines.CoroutineContext
            public <R> R fold(R initial, Function2<? super R, ? super CoroutineContext.Element, ? extends R> operation) {
                return (R) completableDeferredCompletableDeferred$default.fold(initial, operation);
            }

            @Override // kotlin.coroutines.CoroutineContext.Element, kotlin.coroutines.CoroutineContext
            public <E extends CoroutineContext.Element> E get(CoroutineContext.Key<E> key) {
                return (E) completableDeferredCompletableDeferred$default.get(key);
            }

            @Override // kotlinx.coroutines.Job
            @InternalCoroutinesApi
            public CancellationException getCancellationException() {
                return completableDeferredCompletableDeferred$default.getCancellationException();
            }

            @Override // kotlinx.coroutines.Job
            public Sequence<Job> getChildren() {
                return completableDeferredCompletableDeferred$default.getChildren();
            }

            @Override // kotlinx.coroutines.Deferred
            @ExperimentalCoroutinesApi
            public T getCompleted() {
                return completableDeferredCompletableDeferred$default.getCompleted();
            }

            @Override // kotlinx.coroutines.Deferred
            @ExperimentalCoroutinesApi
            public Throwable getCompletionExceptionOrNull() {
                return completableDeferredCompletableDeferred$default.getCompletionExceptionOrNull();
            }

            @Override // kotlin.coroutines.CoroutineContext.Element
            public CoroutineContext.Key<?> getKey() {
                return completableDeferredCompletableDeferred$default.getKey();
            }

            @Override // kotlinx.coroutines.Deferred
            public SelectClause1<T> getOnAwait() {
                return completableDeferredCompletableDeferred$default.getOnAwait();
            }

            @Override // kotlinx.coroutines.Job
            public SelectClause0 getOnJoin() {
                return completableDeferredCompletableDeferred$default.getOnJoin();
            }

            @Override // kotlinx.coroutines.Job
            public Job getParent() {
                return completableDeferredCompletableDeferred$default.getParent();
            }

            @Override // kotlinx.coroutines.Job
            public DisposableHandle invokeOnCompletion(Function1<? super Throwable, Unit> handler) {
                return completableDeferredCompletableDeferred$default.invokeOnCompletion(handler);
            }

            @Override // kotlinx.coroutines.Job
            @InternalCoroutinesApi
            public DisposableHandle invokeOnCompletion(boolean onCancelling, boolean invokeImmediately, Function1<? super Throwable, Unit> handler) {
                return completableDeferredCompletableDeferred$default.invokeOnCompletion(onCancelling, invokeImmediately, handler);
            }

            @Override // kotlinx.coroutines.Job
            public boolean isActive() {
                return completableDeferredCompletableDeferred$default.isActive();
            }

            @Override // kotlinx.coroutines.Job
            public boolean isCancelled() {
                return completableDeferredCompletableDeferred$default.isCancelled();
            }

            @Override // kotlinx.coroutines.Job
            public boolean isCompleted() {
                return completableDeferredCompletableDeferred$default.isCompleted();
            }

            @Override // kotlinx.coroutines.Job
            public Object join(Continuation<? super Unit> continuation) {
                return completableDeferredCompletableDeferred$default.join(continuation);
            }

            @Override // kotlin.coroutines.CoroutineContext.Element, kotlin.coroutines.CoroutineContext
            public CoroutineContext minusKey(CoroutineContext.Key<?> key) {
                return completableDeferredCompletableDeferred$default.minusKey(key);
            }

            @Override // kotlin.coroutines.CoroutineContext
            public CoroutineContext plus(CoroutineContext context) {
                return completableDeferredCompletableDeferred$default.plus(context);
            }

            @Override // kotlinx.coroutines.Job
            @Deprecated(level = DeprecationLevel.ERROR, message = "Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")
            public Job plus(Job other) {
                return completableDeferredCompletableDeferred$default.plus(other);
            }

            @Override // kotlinx.coroutines.Job
            public boolean start() {
                return completableDeferredCompletableDeferred$default.start();
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void asDeferredImpl$lambda$1(CompletableDeferred completableDeferred, AbstractC1629oU abstractC1629oU) {
        Exception excC = abstractC1629oU.c();
        if (excC != null) {
            completableDeferred.completeExceptionally(excC);
        } else if (((H20) abstractC1629oU).d) {
            Job.DefaultImpls.cancel$default((Job) completableDeferred, (CancellationException) null, 1, (Object) null);
        } else {
            completableDeferred.complete(abstractC1629oU.d());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit asDeferredImpl$lambda$2(C0723ab c0723ab, Throwable th) {
        ((H20) c0723ab.f693a.d).m(null);
        return Unit.INSTANCE;
    }

    public static final <T> AbstractC1629oU asTask(Deferred<? extends T> deferred) {
        C0723ab c0723ab = new C0723ab();
        C1694pU c1694pU = new C1694pU(c0723ab.f693a);
        deferred.invokeOnCompletion(new QI(c0723ab, deferred, c1694pU, 1));
        return c1694pU.f1045a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit asTask$lambda$0(C0723ab c0723ab, Deferred deferred, C1694pU c1694pU, Throwable th) {
        if (th instanceof CancellationException) {
            ((H20) c0723ab.f693a.d).m(null);
            return Unit.INSTANCE;
        }
        Throwable completionExceptionOrNull = deferred.getCompletionExceptionOrNull();
        if (completionExceptionOrNull == null) {
            c1694pU.a(deferred.getCompleted());
        } else {
            Exception c2271yN = completionExceptionOrNull instanceof Exception ? (Exception) completionExceptionOrNull : null;
            if (c2271yN == null) {
                c2271yN = new C2271yN(completionExceptionOrNull);
            }
            c1694pU.f1045a.j(c2271yN);
        }
        return Unit.INSTANCE;
    }

    @ExperimentalCoroutinesApi
    public static final <T> Object await(AbstractC1629oU abstractC1629oU, C0723ab c0723ab, Continuation<? super T> continuation) {
        return awaitImpl(abstractC1629oU, c0723ab, continuation);
    }

    public static final <T> Object await(AbstractC1629oU abstractC1629oU, Continuation<? super T> continuation) {
        return awaitImpl(abstractC1629oU, null, continuation);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final <T> Object awaitImpl(AbstractC1629oU abstractC1629oU, final C0723ab c0723ab, Continuation<? super T> continuation) throws Exception {
        if (abstractC1629oU.e()) {
            Exception excC = abstractC1629oU.c();
            if (excC != null) {
                throw excC;
            }
            if (!((H20) abstractC1629oU).d) {
                return abstractC1629oU.d();
            }
            throw new CancellationException("Task " + abstractC1629oU + " was cancelled normally.");
        }
        final CancellableContinuationImpl cancellableContinuationImpl = new CancellableContinuationImpl(IntrinsicsKt.intercepted(continuation), 1);
        cancellableContinuationImpl.initCancellability();
        abstractC1629oU.a(DirectExecutor.INSTANCE, new MC() { // from class: kotlinx.coroutines.tasks.TasksKt$awaitImpl$2$1
            @Override // a.MC
            public final void onComplete(AbstractC1629oU abstractC1629oU2) {
                Exception excC2 = abstractC1629oU2.c();
                if (excC2 != null) {
                    Continuation continuation2 = cancellableContinuationImpl;
                    Result.Companion companion = Result.INSTANCE;
                    continuation2.resumeWith(Result.m33constructorimpl(ResultKt.createFailure(excC2)));
                } else {
                    if (((H20) abstractC1629oU2).d) {
                        CancellableContinuation.DefaultImpls.cancel$default(cancellableContinuationImpl, null, 1, null);
                        return;
                    }
                    Continuation continuation3 = cancellableContinuationImpl;
                    Result.Companion companion2 = Result.INSTANCE;
                    continuation3.resumeWith(Result.m33constructorimpl(abstractC1629oU2.d()));
                }
            }
        });
        if (c0723ab != null) {
            cancellableContinuationImpl.invokeOnCancellation(new Function1<Throwable, Unit>() { // from class: kotlinx.coroutines.tasks.TasksKt$awaitImpl$2$2
                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(Throwable th) {
                    invoke2(th);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2(Throwable th) {
                    ((H20) c0723ab.f693a.d).m(null);
                }
            });
        }
        Object result = cancellableContinuationImpl.getResult();
        if (result == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            DebugProbesKt.probeCoroutineSuspended(continuation);
        }
        return result;
    }
}
