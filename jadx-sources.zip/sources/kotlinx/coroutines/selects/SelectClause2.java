package kotlinx.coroutines.selects;

import kotlin.Metadata;

/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bv\u0018\u0000*\u0006\b\u0000\u0010\u0001 \u0000*\u0006\b\u0001\u0010\u0002 \u00012\u00020\u0003\u0082\u0001\u0001\u0004¨\u0006\u0005"}, d2 = {"Lkotlinx/coroutines/selects/SelectClause2;", "P", "Q", "Lkotlinx/coroutines/selects/SelectClause;", "Lkotlinx/coroutines/selects/SelectClause2Impl;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 0, 0}, xi = 48)
public interface SelectClause2<P, Q> extends SelectClause {
}
